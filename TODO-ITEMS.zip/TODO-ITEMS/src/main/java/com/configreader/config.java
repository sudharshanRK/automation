package com.configreader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class config {
	public static Properties p;
	

	public config() throws IOException {
	
	File f = new File("C:\\Users\\sudharshanaraj\\OneDrive\\Desktop\\ECLIPSE\\TODO-ITEMS\\config.properties");
	FileInputStream fi = new FileInputStream(f);
	p=new Properties();
	p.load(fi);
}


	public String getURL() {
		String refurl = p.getProperty("url");
		return refurl;
	}
	
	public String list() {
		String refurl = p.getProperty("first");
		return refurl;
	}
}
