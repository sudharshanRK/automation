package com.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Navigate_to_url_01 {

	public WebDriver driver;
	
	@FindBy (xpath = "//input[@placeholder='What needs to be done?']")
	private WebElement placeholder;
	
	public WebElement getPlaceholder() {
		return placeholder;
		
	}
	public  Navigate_to_url_01(WebDriver d) {
		driver = d;
		PageFactory.initElements(driver, this);
	}
}
	
	
	
	


