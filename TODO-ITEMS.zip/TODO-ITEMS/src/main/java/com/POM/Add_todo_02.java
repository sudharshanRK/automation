package com.POM;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Add_todo_02 {
	public WebDriver driver;
	
	@FindBy(xpath = "//input[@class='toggle']")
	private WebElement toggle;
	
	@FindBy(xpath = "//button[@class='destroy']")
	private WebElement delete;

	@FindBy(xpath = "//a[text()=['Completed']")
	private WebElement filter;
	
	public WebElement getToggle() {
		return toggle;
	}

	
	public WebElement filteroption() {
		return filter;
	}
	

	public WebElement getDelete() {
		return delete;
	}

	public  Add_todo_02(WebDriver d) {
		driver = d;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
