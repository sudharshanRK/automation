package com.base;

import org.openqa.selenium.Keys;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class todo {
	
	public static WebDriver driver;

	public static WebDriver browserlaunch(String type) {
		if (type.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}else if (type.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		return driver;
	}
	
	public static void geturl(String url) {
		driver.get(url);
	}
	
	public static void maxi() {
		driver.manage().window().maximize();
	}

	public static void click(WebElement ele) {
		ele.click();
	}
	
	public static void inputvalue(WebElement ele, String value) {
	ele.sendKeys(value);
	ele.sendKeys(Keys.ENTER);
	}
	
	public static void wait(int timeouts) throws Exception{
		Thread.sleep(timeouts);
	}
	
	
}
	