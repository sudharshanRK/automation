package com.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.POM.Add_todo_02;
import com.POM.Navigate_to_url_01;


public class pageobject {

	public WebDriver driver;
	
	private Navigate_to_url_01 navi;
	private Add_todo_02 add;
	
	public  pageobject(WebDriver d) {
		driver = d;
		PageFactory.initElements(driver, this);
	}
public Navigate_to_url_01 getNavi() {
navi = new Navigate_to_url_01(driver);
return navi;
	}
	
public Add_todo_02 add() {
add = new Add_todo_02(driver);
return add;
}
}
