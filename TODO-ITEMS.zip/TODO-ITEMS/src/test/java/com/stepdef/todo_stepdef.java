package com.stepdef;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.SendKeysAction;

import com.base.todo;
import com.configreader.config;
import com.pageobject.pageobject;
import com.runner.runner;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class todo_stepdef extends todo{

	public WebDriver driver = runner.driver;
	pageobject p = new pageobject(driver);
	config c;
	
    @Before
    public void setUp() throws IOException {
        c = new config();
    }
	
	
	@Given("Navigate to demo blaze")
	public void navigate_to_demo_blaze()throws IOException {
	   c = new config();
	   geturl(c.getURL());
	   maxi();
	}

	@Given("Add some todos in the list")
	public void add_some_todos_in_the_list() {
	click(p.getNavi().getPlaceholder());
	}

	@Given("User should be able to select the enter")
	public void user_should_be_able_to_select_the_enter() {
		inputvalue(p.getNavi().getPlaceholder(), c.list());
		
	}

	@Given("added todo is displayed")
	public void added_todo_is_displayed() throws Exception {
		wait(2000);
		click(p.add().getToggle());
	}

	@Given("User should be able to select")
	public void user_should_be_able_to_select() throws Exception {
		wait(3000);
		click(p.add().getDelete());
	}

	@Given("user should be able to delete")
	public void user_should_be_able_to_delete() throws Exception {
		wait(3000);
		inputvalue(p.getNavi().getPlaceholder(), c.list());
	}

	@Then("user can able to perform filter operation")
	public void user_can_able_to_perform_filter_operation() throws Exception {
		wait(3000);
		click(p.add().filteroption());
	}

}
