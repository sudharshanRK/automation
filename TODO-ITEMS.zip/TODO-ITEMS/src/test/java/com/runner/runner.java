package com.runner;

import org.junit.BeforeClass;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import com.base.todo;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\sudharshanaraj\\OneDrive\\Desktop\\ECLIPSE\\TODO-ITEMS\\src\\test\\java\\com\\feature\\todo.feature",glue="com.stepdef")
public class runner extends todo {

	public static WebDriver driver;
	@BeforeClass
	public static void setup() {
		driver = browserlaunch("chrome");
	}
}
